#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# setup_db.sh  –  Creates the local PostgreSQL user + database for punch system
# Run once as a user who can sudo / has psql access.
# ─────────────────────────────────────────────────────────────────────────────

set -e

DB_NAME="punch_db"
DB_USER="punch_user"
DB_PASS="punch_pass"

echo "==> Creating PostgreSQL user: $DB_USER"
sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';" 2>/dev/null || \
  echo "    User already exists, skipping."

echo "==> Creating database: $DB_NAME"
sudo -u postgres psql -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;" 2>/dev/null || \
  echo "    Database already exists, skipping."

echo "==> Granting privileges"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"

echo ""
echo "✅  Database ready!"
echo "    Host:     localhost"
echo "    Port:     5432"
echo "    Database: $DB_NAME"
echo "    User:     $DB_USER"
echo "    Password: $DB_PASS"
echo ""
echo "Next: run  python -m alembic upgrade head  to create tables."
