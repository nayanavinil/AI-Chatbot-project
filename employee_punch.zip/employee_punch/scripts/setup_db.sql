-- setup_db.sql
-- Run this in pgAdmin or psql as the postgres superuser on Windows/Mac/Linux
-- psql -U postgres -f scripts/setup_db.sql

CREATE USER punch_user WITH PASSWORD 'punch_pass';
CREATE DATABASE punch_db OWNER punch_user;
GRANT ALL PRIVILEGES ON DATABASE punch_db TO punch_user;

\echo '✅ Database punch_db and user punch_user created successfully.'
\echo 'Now run: alembic upgrade head'
