"""
APScheduler background job – syncs fingerprint device every 5 minutes.
Imported and started from main.py on startup.
"""
from apscheduler.schedulers.background import BackgroundScheduler
from sqlalchemy.orm import Session
from .database import SessionLocal
from .models import Attendance, Employee, SyncLog
from .fingerprint.zklib_handler import FingerprintHandler
import logging

logger    = logging.getLogger(__name__)
_scheduler = None


def _sync_job():
    db: Session = SessionLocal()
    try:
        handler = FingerprintHandler()
        logs    = handler.get_attendance_logs()
        synced  = 0

        for log in logs:
            emp = db.query(Employee).filter(Employee.device_uid == log.user_id).first()
            if not emp:
                continue

            log_date = log.timestamp.date()
            record   = db.query(Attendance).filter(
                Attendance.employee_id == emp.id,
                Attendance.date        == log_date,
            ).first()

            if not record:
                db.add(Attendance(
                    employee_id=emp.id,
                    date=log_date,
                    punch_in=log.timestamp,
                    status="present"
                ))
                synced += 1
            elif record.punch_out is None or log.timestamp > record.punch_out:
                record.punch_out = log.timestamp
                synced += 1

        db.commit()
        db.add(SyncLog(records_in=len(logs), records_new=synced, status="success",
                       message=f"Auto-sync: {synced} records"))
        db.commit()
        logger.info(f"[Scheduler] Auto-sync complete – {synced}/{len(logs)} records updated")

    except Exception as e:
        logger.error(f"[Scheduler] Sync failed: {e}")
        try:
            db.add(SyncLog(records_in=0, records_new=0, status="failed", message=str(e)))
            db.commit()
        except Exception:
            pass
    finally:
        db.close()


def start_scheduler(interval_minutes: int = 5):
    global _scheduler
    _scheduler = BackgroundScheduler(timezone="UTC")
    _scheduler.add_job(_sync_job, "interval", minutes=interval_minutes, id="fp_sync")
    _scheduler.start()
    logger.info(f"[Scheduler] Auto-sync started – every {interval_minutes} minutes")
    return _scheduler


def stop_scheduler():
    global _scheduler
    if _scheduler and _scheduler.running:
        _scheduler.shutdown(wait=False)
        logger.info("[Scheduler] Stopped")
