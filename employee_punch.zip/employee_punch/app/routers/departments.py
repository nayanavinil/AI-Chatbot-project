from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from ..database import get_db
from ..models import Department, AdminUser
from ..schemas import DepartmentCreate, DepartmentOut
from ..auth_utils import get_current_admin

router = APIRouter(prefix="/departments", tags=["Departments"])


@router.post("/", response_model=DepartmentOut)
def create(payload: DepartmentCreate, db: Session = Depends(get_db), _=Depends(get_current_admin)):
    if db.query(Department).filter(Department.name == payload.name).first():
        raise HTTPException(status_code=400, detail="Department already exists")
    dept = Department(name=payload.name)
    db.add(dept)
    db.commit()
    db.refresh(dept)
    return dept


@router.get("/", response_model=List[DepartmentOut])
def list_all(db: Session = Depends(get_db), _=Depends(get_current_admin)):
    return db.query(Department).all()


@router.delete("/{dept_id}")
def delete(dept_id: int, db: Session = Depends(get_db), _=Depends(get_current_admin)):
    dept = db.query(Department).filter(Department.id == dept_id).first()
    if not dept:
        raise HTTPException(status_code=404, detail="Not found")
    db.delete(dept)
    db.commit()
    return {"message": f"Department '{dept.name}' deleted"}