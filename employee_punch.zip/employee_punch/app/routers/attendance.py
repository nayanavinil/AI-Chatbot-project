from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date, datetime
from ..database import get_db
from ..models import Attendance, Employee, SyncLog, AdminUser
from ..schemas import AttendanceOut, AttendanceUpdate, SyncResult
from ..auth_utils import get_current_admin
from ..fingerprint.zklib_handler import FingerprintHandler
import logging

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/attendance", tags=["Attendance"])


def _do_sync(db: Session, clear_after: bool = False) -> SyncResult:
    """Core sync logic – reused by API endpoint and scheduler."""
    handler   = FingerprintHandler()
    logs      = handler.get_attendance_logs()
    synced    = 0
    skipped   = 0

    for log in logs:
        emp = db.query(Employee).filter(Employee.device_uid == log.user_id).first()
        if not emp:
            skipped += 1
            continue

        log_date = log.timestamp.date()
        record   = db.query(Attendance).filter(
            Attendance.employee_id == emp.id,
            Attendance.date        == log_date,
        ).first()

        if not record:
            db.add(Attendance(
                employee_id=emp.id,
                date=log_date,
                punch_in=log.timestamp,
                status="present"
            ))
            synced += 1
        else:
            if record.punch_out is None or log.timestamp > record.punch_out:
                record.punch_out = log.timestamp
                synced += 1

    db.commit()

    if clear_after:
        handler.clear_attendance_logs()

    result = SyncResult(
        total_logs=len(logs),
        synced=synced,
        skipped=skipped,
        message=f"Sync complete – {synced} updated, {skipped} unknown UIDs skipped"
    )

    # Write audit log
    db.add(SyncLog(
        records_in=len(logs),
        records_new=synced,
        status="success",
        message=result.message
    ))
    db.commit()
    return result


@router.post("/sync", response_model=SyncResult, summary="Pull logs from fingerprint device")
def sync_attendance(
    clear_after: bool = Query(False, description="Clear device logs after syncing"),
    db: Session = Depends(get_db),
    _=Depends(get_current_admin)
):
    try:
        return _do_sync(db, clear_after)
    except Exception as e:
        db.add(SyncLog(records_in=0, records_new=0, status="failed", message=str(e)))
        db.commit()
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/", response_model=List[AttendanceOut], summary="List attendance records")
def list_attendance(
    emp_id:    Optional[int]  = Query(None),
    from_date: Optional[date] = Query(None),
    to_date:   Optional[date] = Query(None),
    status:    Optional[str]  = Query(None),
    db: Session = Depends(get_db),
    _=Depends(get_current_admin)
):
    q = db.query(Attendance)
    if emp_id:    q = q.filter(Attendance.employee_id == emp_id)
    if from_date: q = q.filter(Attendance.date >= from_date)
    if to_date:   q = q.filter(Attendance.date <= to_date)
    if status:    q = q.filter(Attendance.status == status)
    return q.order_by(Attendance.date.desc()).all()


@router.put("/{att_id}", response_model=AttendanceOut, summary="Manually correct a record")
def update_record(
    att_id: int,
    payload: AttendanceUpdate,
    db: Session = Depends(get_db),
    _=Depends(get_current_admin)
):
    record = db.query(Attendance).filter(Attendance.id == att_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Record not found")
    for k, v in payload.model_dump(exclude_unset=True).items():
        setattr(record, k, v)
    db.commit()
    db.refresh(record)
    return record


@router.get("/report/today", summary="Today's attendance summary")
def today_summary(db: Session = Depends(get_db), _=Depends(get_current_admin)):
    today   = date.today()
    total   = db.query(Employee).filter(Employee.is_active == True).count()
    present = db.query(Attendance).filter(Attendance.date == today).count()
    return {
        "date":    str(today),
        "total":   total,
        "present": present,
        "absent":  total - present,
    }


@router.get("/report/monthly", summary="Monthly attendance summary per employee")
def monthly_summary(
    year:  int = Query(...),
    month: int = Query(...),
    db: Session = Depends(get_db),
    _=Depends(get_current_admin)
):
    from sqlalchemy import extract
    records = (
        db.query(Attendance)
        .filter(
            extract("year",  Attendance.date) == year,
            extract("month", Attendance.date) == month,
        )
        .all()
    )
    summary = {}
    for r in records:
        emp_id = r.employee_id
        if emp_id not in summary:
            summary[emp_id] = {"employee_id": emp_id, "present": 0, "half_day": 0}
        if r.status == "present":
            summary[emp_id]["present"] += 1
        elif r.status == "half_day":
            summary[emp_id]["half_day"] += 1
    return list(summary.values())


@router.get("/device/ping", summary="Test connection to fingerprint device")
def ping_device(_=Depends(get_current_admin)):
    ok = FingerprintHandler().test_connection()
    return {"device_reachable": ok}


@router.get("/device/info", summary="Get fingerprint device details")
def device_info(_=Depends(get_current_admin)):
    try:
        return FingerprintHandler().get_device_info()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/sync/logs", summary="View sync audit log")
def sync_logs(db: Session = Depends(get_db), _=Depends(get_current_admin)):
    from ..models import SyncLog
    return db.query(SyncLog).order_by(SyncLog.synced_at.desc()).limit(50).all()