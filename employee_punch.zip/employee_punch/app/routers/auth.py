from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from datetime import datetime
from ..database import get_db
from ..models import AdminUser
from ..schemas import AdminCreate, Token, AdminOut
from ..auth_utils import hash_password, verify_password, create_access_token, get_current_admin

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/register", response_model=AdminOut, summary="Register admin (first-time setup)")
def register(payload: AdminCreate, db: Session = Depends(get_db)):
    if db.query(AdminUser).filter(AdminUser.username == payload.username).first():
        raise HTTPException(status_code=400, detail="Username already exists")
    try:
        hashed = hash_password(payload.password)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    admin = AdminUser(
        username=payload.username,
        full_name=payload.full_name,
        password_hash=hashed,
        is_superadmin=(db.query(AdminUser).count() == 0),  # first user = superadmin
    )
    db.add(admin)
    db.commit()
    db.refresh(admin)
    return admin


@router.post("/login", response_model=Token, summary="Login – returns JWT token")
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    admin = db.query(AdminUser).filter(AdminUser.username == form.username).first()
    if not admin or not verify_password(form.password, admin.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    if not admin.is_active:
        raise HTTPException(status_code=403, detail="Account is disabled")

    admin.last_login = datetime.utcnow()
    db.commit()

    token = create_access_token({"sub": admin.username})
    return {"access_token": token, "token_type": "bearer"}


@router.get("/me", response_model=AdminOut, summary="Current admin info")
def me(current: AdminUser = Depends(get_current_admin)):
    return current


@router.get("/admins", response_model=list[AdminOut], summary="List all admins (superadmin only)")
def list_admins(db: Session = Depends(get_db), current: AdminUser = Depends(get_current_admin)):
    if not current.is_superadmin:
        raise HTTPException(status_code=403, detail="Superadmin access required")
    return db.query(AdminUser).all()