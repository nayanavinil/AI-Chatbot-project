from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from ..database import get_db
from ..models import Employee, AdminUser
from ..schemas import EmployeeCreate, EmployeeUpdate, EmployeeOut
from ..auth_utils import get_current_admin
from ..fingerprint.zklib_handler import FingerprintHandler
import logging

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/employees", tags=["Employees"])


@router.post("/", response_model=EmployeeOut, summary="Add a new employee")
def create_employee(
    payload: EmployeeCreate,
    db: Session = Depends(get_db),
    _=Depends(get_current_admin)
):
    if db.query(Employee).filter(Employee.employee_code == payload.employee_code).first():
        raise HTTPException(status_code=400, detail="Employee code already in use")
    if payload.email and db.query(Employee).filter(Employee.email == payload.email).first():
        raise HTTPException(status_code=400, detail="Email already in use")

    emp = Employee(**payload.model_dump())
    db.add(emp)
    db.commit()
    db.refresh(emp)

    # Try to register on fingerprint device
    if emp.device_uid:
        try:
            FingerprintHandler().enroll_user(uid=emp.device_uid, name=emp.name)
        except Exception as e:
            logger.warning(f"Device enroll skipped: {e}")

    return emp


@router.get("/", response_model=List[EmployeeOut], summary="List employees")
def list_employees(
    active_only: bool = True,
    department_id: Optional[int] = None,
    db: Session = Depends(get_db),
    _=Depends(get_current_admin)
):
    q = db.query(Employee)
    if active_only:
        q = q.filter(Employee.is_active == True)
    if department_id:
        q = q.filter(Employee.department_id == department_id)
    return q.order_by(Employee.name).all()


@router.get("/{emp_id}", response_model=EmployeeOut)
def get_employee(emp_id: int, db: Session = Depends(get_db), _=Depends(get_current_admin)):
    emp = db.query(Employee).filter(Employee.id == emp_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")
    return emp


@router.put("/{emp_id}", response_model=EmployeeOut, summary="Update employee")
def update_employee(
    emp_id: int,
    payload: EmployeeUpdate,
    db: Session = Depends(get_db),
    _=Depends(get_current_admin)
):
    emp = db.query(Employee).filter(Employee.id == emp_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")

    old_uid = emp.device_uid
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(emp, field, value)
    db.commit()
    db.refresh(emp)

    # Re-enroll if device_uid changed
    if emp.device_uid and emp.device_uid != old_uid:
        try:
            FingerprintHandler().enroll_user(uid=emp.device_uid, name=emp.name)
        except Exception as e:
            logger.warning(f"Device re-enroll skipped: {e}")

    return emp


@router.delete("/{emp_id}", summary="Deactivate employee")
def deactivate(emp_id: int, db: Session = Depends(get_db), _=Depends(get_current_admin)):
    emp = db.query(Employee).filter(Employee.id == emp_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")

    emp.is_active = False
    db.commit()

    if emp.device_uid:
        try:
            FingerprintHandler().delete_user(uid=emp.device_uid)
        except Exception as e:
            logger.warning(f"Device delete skipped: {e}")

    return {"message": f"Employee '{emp.name}' deactivated"}