"""
ZKTeco fingerprint machine handler.
Uses the `pyzk` library to communicate over TCP/IP.

Tested with: ZKTeco K40, K80, F18, iClock series.
"""
from zk import ZK, const
from app.config import DEVICE_IP, DEVICE_PORT
import logging

logger = logging.getLogger(__name__)

try:
    from app.config import DEVICE_IP, DEVICE_PORT
except ImportError:
    import os
    DEVICE_IP   = os.getenv("DEVICE_IP", "192.168.1.201")
    DEVICE_PORT = int(os.getenv("DEVICE_PORT", 4370))


class FingerprintHandler:
    def __init__(self, ip: str = None, port: int = None):
        self.ip   = ip   or DEVICE_IP
        self.port = port or DEVICE_PORT
        self.zk   = ZK(
            self.ip,
            port=self.port,
            timeout=10,
            password=0,
            force_udp=False,
            ommit_ping=False
        )

    # ── Internal ──────────────────────────────────────────────────────────────
    def _connect(self):
        return self.zk.connect()

    # ── Attendance ────────────────────────────────────────────────────────────
    def get_attendance_logs(self) -> list:
        """Return all punch log records from the device."""
        conn = None
        try:
            conn = self._connect()
            conn.disable_device()
            logs = conn.get_attendance()
            logger.info(f"[ZK] Fetched {len(logs)} attendance records from {self.ip}")
            return logs
        except Exception as e:
            logger.error(f"[ZK] get_attendance_logs failed: {e}")
            raise RuntimeError(f"Device error: {e}")
        finally:
            if conn:
                conn.enable_device()
                conn.disconnect()

    def clear_attendance_logs(self) -> bool:
        """Wipe all attendance logs on the device (call after syncing)."""
        conn = None
        try:
            conn = self._connect()
            conn.disable_device()
            conn.clear_attendance()
            logger.info(f"[ZK] Attendance logs cleared on {self.ip}")
            return True
        except Exception as e:
            logger.error(f"[ZK] clear_attendance_logs failed: {e}")
            raise RuntimeError(f"Device error: {e}")
        finally:
            if conn:
                conn.enable_device()
                conn.disconnect()

    # ── Users ─────────────────────────────────────────────────────────────────
    def get_all_users(self) -> list:
        """Return all users registered on the device."""
        conn = None
        try:
            conn = self._connect()
            users = conn.get_users()
            return users
        except Exception as e:
            raise RuntimeError(f"Device error: {e}")
        finally:
            if conn:
                conn.disconnect()

    def enroll_user(self, uid: int, name: str, privilege: int = const.USER_DEFAULT) -> bool:
        """Add / update a user on the fingerprint device."""
        conn = None
        try:
            conn = self._connect()
            conn.set_user(
                uid=uid,
                name=name[:24],         # device name limit
                privilege=privilege,
                password='',
                group_id='',
                user_id=str(uid)
            )
            logger.info(f"[ZK] Enrolled user uid={uid} name={name}")
            return True
        except Exception as e:
            raise RuntimeError(f"Enroll failed: {e}")
        finally:
            if conn:
                conn.disconnect()

    def delete_user(self, uid: int) -> bool:
        """Remove a user from the fingerprint device."""
        conn = None
        try:
            conn = self._connect()
            conn.delete_user(uid=uid)
            logger.info(f"[ZK] Deleted user uid={uid}")
            return True
        except Exception as e:
            raise RuntimeError(f"Delete failed: {e}")
        finally:
            if conn:
                conn.disconnect()

    # ── Device Info ───────────────────────────────────────────────────────────
    def get_device_info(self) -> dict:
        conn = None
        try:
            conn = self._connect()
            return {
                "ip":               self.ip,
                "port":             self.port,
                "firmware_version": conn.get_firmware_version(),
                "serial_number":    conn.get_serialnumber(),
                "platform":         conn.get_platform(),
                "device_name":      conn.get_device_name(),
                "user_count":       len(conn.get_users()),
            }
        except Exception as e:
            raise RuntimeError(f"Device info failed: {e}")
        finally:
            if conn:
                conn.disconnect()

    def test_connection(self) -> bool:
        """Quick ping to verify device is reachable."""
        try:
            conn = self._connect()
            conn.disconnect()
            return True
        except Exception:
            return False