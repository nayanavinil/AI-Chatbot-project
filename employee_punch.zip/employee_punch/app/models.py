from sqlalchemy import (
    Column, Integer, String, DateTime, Boolean,
    ForeignKey, LargeBinary, Date, UniqueConstraint
)
from sqlalchemy.orm import relationship
from datetime import datetime
from .database import Base


class Department(Base):
    __tablename__ = "departments"

    id         = Column(Integer, primary_key=True, index=True)
    name       = Column(String(100), unique=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    employees  = relationship("Employee", back_populates="dept")
    def __str__(self):
        return self.name


class Employee(Base):
    __tablename__ = "employees"

    id            = Column(Integer, primary_key=True, index=True)
    name          = Column(String(100), nullable=False)
    employee_code = Column(String(50), unique=True, nullable=False)
    department_id = Column(Integer, ForeignKey("departments.id"), nullable=True)
    email         = Column(String(150), unique=True, nullable=True)
    phone         = Column(String(20), nullable=True)
    device_uid    = Column(Integer, unique=True, nullable=True)   # UID on ZKTeco device
    fingerprint   = Column(LargeBinary, nullable=True)            # raw template (optional backup)
    is_active     = Column(Boolean, default=True)
    joined_date   = Column(Date, nullable=True)
    created_at    = Column(DateTime, default=datetime.utcnow)
    updated_at    = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    dept        = relationship("Department", back_populates="employees")
    attendances = relationship("Attendance", back_populates="employee", cascade="all, delete-orphan")
    def __str__(self):
        return f"{self.name} ({self.employee_code})"


class Attendance(Base):
    __tablename__ = "attendance"
    __table_args__ = (
        UniqueConstraint("employee_id", "date", name="uq_employee_date"),
    )

    id          = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id", ondelete="CASCADE"), nullable=False)
    date        = Column(Date, nullable=False, index=True)
    punch_in    = Column(DateTime, nullable=True)
    punch_out   = Column(DateTime, nullable=True)
    status      = Column(String(20), default="present")   # present | absent | half_day
    created_at  = Column(DateTime, default=datetime.utcnow)
    updated_at  = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    employee    = relationship("Employee", back_populates="attendances")


class AdminUser(Base):
    __tablename__ = "admin_users"

    id            = Column(Integer, primary_key=True, index=True)
    username      = Column(String(80), unique=True, nullable=False)
    full_name     = Column(String(120), nullable=True)
    password_hash = Column(String(255), nullable=False)
    is_superadmin = Column(Boolean, default=False)
    is_active     = Column(Boolean, default=True)
    last_login    = Column(DateTime, nullable=True)
    created_at    = Column(DateTime, default=datetime.utcnow)


class SyncLog(Base):
    """Track every device sync for audit purposes."""
    __tablename__ = "sync_logs"

    id          = Column(Integer, primary_key=True, index=True)
    synced_at   = Column(DateTime, default=datetime.utcnow)
    records_in  = Column(Integer, default=0)
    records_new = Column(Integer, default=0)
    status      = Column(String(20), default="success")   # success | failed
    message     = Column(String(500), nullable=True)
