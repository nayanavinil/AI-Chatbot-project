from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime, date


# ── Department ────────────────────────────────────────────────────────────────
class DepartmentCreate(BaseModel):
    name: str

class DepartmentOut(BaseModel):
    id: int
    name: str
    class Config:
        from_attributes = True


# ── Employee ──────────────────────────────────────────────────────────────────
class EmployeeCreate(BaseModel):
    name:          str
    employee_code: str
    department_id: Optional[int] = None
    email:         Optional[str] = None
    phone:         Optional[str] = None
    device_uid:    Optional[int] = None
    joined_date:   Optional[date] = None

class EmployeeUpdate(BaseModel):
    name:          Optional[str]  = None
    department_id: Optional[int]  = None
    email:         Optional[str]  = None
    phone:         Optional[str]  = None
    device_uid:    Optional[int]  = None
    is_active:     Optional[bool] = None
    joined_date:   Optional[date] = None

class EmployeeOut(BaseModel):
    id:            int
    name:          str
    employee_code: str
    department_id: Optional[int]
    email:         Optional[str]
    phone:         Optional[str]
    device_uid:    Optional[int]
    is_active:     bool
    joined_date:   Optional[date]
    created_at:    datetime
    class Config:
        from_attributes = True


# ── Attendance ────────────────────────────────────────────────────────────────
class AttendanceOut(BaseModel):
    id:          int
    employee_id: int
    date:        date
    punch_in:    Optional[datetime]
    punch_out:   Optional[datetime]
    status:      str
    class Config:
        from_attributes = True

class AttendanceUpdate(BaseModel):
    punch_in:  Optional[datetime] = None
    punch_out: Optional[datetime] = None
    status:    Optional[str]      = None


# ── Auth ──────────────────────────────────────────────────────────────────────
class AdminCreate(BaseModel):
    username:  str
    password:  str
    full_name: Optional[str] = None

class Token(BaseModel):
    access_token: str
    token_type:   str

class AdminOut(BaseModel):
    id:            int
    username:      str
    full_name:     Optional[str]
    is_superadmin: bool
    is_active:     bool
    last_login:    Optional[datetime]
    class Config:
        from_attributes = True


# ── Sync ──────────────────────────────────────────────────────────────────────
class SyncResult(BaseModel):
    total_logs:  int
    synced:      int
    skipped:     int
    message:     str
