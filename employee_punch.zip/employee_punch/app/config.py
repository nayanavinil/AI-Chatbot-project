from dotenv import load_dotenv
import os

load_dotenv()

DATABASE_URL                = os.getenv("DATABASE_URL", "postgresql://punch_user:punch_pass@localhost:5432/punch_db")
SECRET_KEY                  = os.getenv("SECRET_KEY", "changeme-use-a-real-secret")
ALGORITHM                   = os.getenv("ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", 60))
DEVICE_IP                   = os.getenv("DEVICE_IP", "192.168.1.201")
DEVICE_PORT                 = int(os.getenv("DEVICE_PORT", 4370))
APP_HOST                    = os.getenv("APP_HOST", "0.0.0.0")
APP_PORT                    = int(os.getenv("APP_PORT", 8000))
DEBUG                       = os.getenv("DEBUG", "false").lower() == "true"