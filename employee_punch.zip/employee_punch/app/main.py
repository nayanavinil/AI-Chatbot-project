"""
main.py – Employee Fingerprint Punch System
"""
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.sessions import SessionMiddleware
from starlette.requests import Request
from sqladmin import Admin as SQLAdmin, ModelView
from sqladmin.authentication import AuthenticationBackend

from .database import engine, Base, SessionLocal
from .models import Employee, Attendance, AdminUser, Department, SyncLog
from .routers import auth, employees, attendance, departments
from .scheduler import start_scheduler, stop_scheduler
from .auth_utils import hash_password, verify_password
from .config import SECRET_KEY

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(name)s – %(message)s")
logger = logging.getLogger(__name__)


# ── Admin Auth ────────────────────────────────────────────────────────────────
class AdminAuth(AuthenticationBackend):

    async def login(self, request: Request) -> bool:
        form     = await request.form()
        username = form.get("username", "")
        password = form.get("password", "")

        db = SessionLocal()
        try:
            admin = db.query(AdminUser).filter(
                AdminUser.username  == username,
                AdminUser.is_active == True
            ).first()
            if admin and verify_password(password, admin.password_hash):
                request.session.update({"admin": username})
                return True
        finally:
            db.close()
        return False

    async def logout(self, request: Request) -> bool:
        request.session.clear()
        return True

    async def authenticate(self, request: Request) -> bool:
        return "admin" in request.session


# ── Lifespan ──────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    logger.info("✅  Database tables ready")

    db = SessionLocal()
    try:
        if not db.query(AdminUser).first():
            db.add(AdminUser(
                username="admin",
                full_name="Super Admin",
                password_hash=hash_password("admin123"),
                is_superadmin=True,
            ))
            db.commit()
            logger.warning("🔑  Default admin: username=admin  password=admin123")
    finally:
        db.close()

    start_scheduler(interval_minutes=5)
    yield
    stop_scheduler()


# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Employee Fingerprint Punch System",
    version="1.0.0",
    lifespan=lifespan,
)

# ✅ SessionMiddleware MUST come before SQLAdmin is initialized
app.add_middleware(SessionMiddleware, secret_key=SECRET_KEY)
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(auth.router)
app.include_router(departments.router)
app.include_router(employees.router)
app.include_router(attendance.router)

# ── SQLAdmin ──────────────────────────────────────────────────────────────────
# ✅ authentication_backend passed here — this is what enforces the login page
admin_panel = SQLAdmin(
    app,
    engine,
    title="Punch System Admin",
    base_url="/admin",
    authentication_backend=AdminAuth(secret_key=SECRET_KEY),
)


class EmployeeAdmin(ModelView, model=Employee):
    icon                   = "fa-solid fa-users"
    column_list            = [Employee.id, Employee.name, Employee.employee_code,
                               Employee.department_id, Employee.device_uid,
                               Employee.is_active, Employee.created_at]
    column_searchable_list = [Employee.name, Employee.employee_code, Employee.email]
    column_sortable_list   = [Employee.id, Employee.name, Employee.created_at]
    form_excluded_columns  = ["fingerprint", "attendances", "created_at", "updated_at"]
    name_plural            = "Employees"


class AttendanceAdmin(ModelView, model=Attendance):
    icon                 = "fa-solid fa-clock"
    column_list          = [Attendance.id, Attendance.employee_id, Attendance.date,
                             Attendance.punch_in, Attendance.punch_out, Attendance.status]
    column_sortable_list = [Attendance.date, Attendance.punch_in, Attendance.employee_id]
    name_plural          = "Attendance Records"


class DepartmentAdmin(ModelView, model=Department):
    icon        = "fa-solid fa-building"
    column_list = [Department.id, Department.name, Department.created_at]
    name_plural = "Departments"


class AdminUserAdmin(ModelView, model=AdminUser):
    icon                  = "fa-solid fa-user-shield"
    column_list           = [AdminUser.id, AdminUser.username, AdminUser.full_name,
                              AdminUser.is_superadmin, AdminUser.is_active, AdminUser.last_login]
    form_excluded_columns = ["password_hash", "created_at", "last_login"]
    name_plural           = "Admin Users"


class SyncLogAdmin(ModelView, model=SyncLog):
    icon        = "fa-solid fa-rotate"
    column_list = [SyncLog.id, SyncLog.synced_at, SyncLog.records_in,
                   SyncLog.records_new, SyncLog.status, SyncLog.message]
    can_create  = False
    can_edit    = False
    can_delete  = False
    name_plural = "Sync Logs"


admin_panel.add_view(EmployeeAdmin)
admin_panel.add_view(AttendanceAdmin)
admin_panel.add_view(DepartmentAdmin)
admin_panel.add_view(AdminUserAdmin)
admin_panel.add_view(SyncLogAdmin)


@app.get("/", tags=["Health"])
def root():
    return {"status": "running", "api_docs": "/docs", "admin": "/admin"}