# 🖐️ Employee Fingerprint Punch System
**Local PostgreSQL · FastAPI · ZKTeco · SQLAdmin**

A production-ready employee attendance system that reads punch data from a ZKTeco fingerprint machine and stores it in a **local PostgreSQL database**.

---

## 📁 Project Structure

```
employee_punch/
├── app/
│   ├── __init__.py
│   ├── main.py            ← FastAPI app + SQLAdmin panel + startup
│   ├── config.py          ← Loads .env settings
│   ├── database.py        ← Local PostgreSQL connection (SQLAlchemy)
│   ├── models.py          ← Tables: Employee, Attendance, Department, AdminUser, SyncLog
│   ├── schemas.py         ← Pydantic request/response models
│   ├── auth_utils.py      ← JWT helpers
│   ├── scheduler.py       ← Auto-sync every 5 min (APScheduler)
│   ├── fingerprint/
│   │   └── zklib_handler.py   ← ZKTeco TCP/IP communication (pyzk)
│   └── routers/
│       ├── auth.py            ← POST /auth/login  /auth/register
│       ├── departments.py     ← CRUD /departments
│       ├── employees.py       ← CRUD /employees
│       └── attendance.py      ← Sync + reports /attendance
├── alembic/               ← DB migrations
│   ├── env.py
│   └── versions/
├── scripts/
│   ├── setup_db.sh        ← Linux/Mac: create DB user + database
│   └── setup_db.sql       ← Windows/pgAdmin: run in psql
├── .env                   ← Your local config (edit this!)
├── .env.example           ← Template
├── requirements.txt
├── alembic.ini
├── run.py                 ← Start server: python run.py
└── README.md
```

---

## ✅ Prerequisites

| Requirement | Notes |
|---|---|
| Python 3.11+ | `python --version` |
| PostgreSQL 14+ | Installed **locally** (not Docker) |
| ZKTeco fingerprint machine | Connected to the same LAN |

---

## 🚀 Setup & Run (Step by Step)

### Step 1 – Install PostgreSQL locally

**Ubuntu/Debian:**
```bash
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

**macOS (Homebrew):**
```bash
brew install postgresql@15
brew services start postgresql@15
```

**Windows:**
Download installer from https://www.postgresql.org/download/windows/

---

### Step 2 – Create the database

**Linux/Mac (terminal):**
```bash
chmod +x scripts/setup_db.sh
./scripts/setup_db.sh
```

**Windows / pgAdmin / psql:**
```sql
-- Run scripts/setup_db.sql as postgres superuser:
psql -U postgres -f scripts/setup_db.sql
```

This creates:
- User:     `punch_user`  password: `punch_pass`
- Database: `punch_db`

---

### Step 3 – Configure your environment

Edit `.env` with your actual values:
```env
DATABASE_URL=postgresql://punch_user:punch_pass@localhost:5432/punch_db
SECRET_KEY=replace_with_long_random_string
DEVICE_IP=192.168.1.201      # ← your fingerprint machine IP
DEVICE_PORT=4370
```

---

### Step 4 – Install Python dependencies

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

---

### Step 5 – Create database tables

```bash
alembic upgrade head
```

Or tables are also auto-created on first run via `Base.metadata.create_all()`.

---

### Step 6 – Start the server

```bash
python run.py
```

---

## 🌐 Access the System

| URL | Description |
|---|---|
| http://localhost:8000 | API health check |
| http://localhost:8000/docs | Swagger UI (interactive API docs) |
| http://localhost:8000/admin | Admin panel (SQLAdmin) |

**Default login:**
```
Username: admin
Password: admin123
```
⚠️ Change this via `POST /auth/register` after first login.

---

## 🗄️ Database (Local PostgreSQL)

The data lives on your **own machine** at:

| OS | Default data directory |
|---|---|
| Linux | `/var/lib/postgresql/15/main/` |
| macOS | `/usr/local/var/postgresql@15/` |
| Windows | `C:\Program Files\PostgreSQL\15\data\` |

### Connect with psql
```bash
psql -U punch_user -d punch_db -h localhost
```

### Connect with pgAdmin / DBeaver / TablePlus
```
Host:     localhost
Port:     5432
Database: punch_db
User:     punch_user
Password: punch_pass
```

### Backup & Restore
```bash
# Backup
pg_dump -U punch_user punch_db > backup_$(date +%F).sql

# Restore
psql -U punch_user punch_db < backup_2025-01-01.sql
```

---

## 📡 API Endpoints

### Auth
| Method | Path | Description |
|---|---|---|
| POST | /auth/register | Create admin account |
| POST | /auth/login | Get JWT token |
| GET  | /auth/me | Current admin info |

### Departments
| Method | Path | Description |
|---|---|---|
| POST | /departments/ | Create department |
| GET  | /departments/ | List departments |
| DELETE | /departments/{id} | Delete department |

### Employees
| Method | Path | Description |
|---|---|---|
| POST | /employees/ | Add employee |
| GET  | /employees/ | List (filter: active, department) |
| GET  | /employees/{id} | Single employee |
| PUT  | /employees/{id} | Update |
| DELETE | /employees/{id} | Deactivate |

### Attendance
| Method | Path | Description |
|---|---|---|
| POST | /attendance/sync | Pull logs from device |
| GET  | /attendance/ | List records (filter by date, emp, status) |
| PUT  | /attendance/{id} | Manually correct a record |
| GET  | /attendance/report/today | Today's summary |
| GET  | /attendance/report/monthly | Monthly report |
| GET  | /attendance/device/ping | Test device connection |
| GET  | /attendance/device/info | Device firmware info |
| GET  | /attendance/sync/logs | Audit log of syncs |

---

## 🖐️ Fingerprint Device Setup

1. Connect ZKTeco device to local network
2. Set a **static IP** on the device (e.g., 192.168.1.201)
3. Enable **TCP/IP** in device settings (port 4370)
4. Update `DEVICE_IP` in `.env`
5. When adding an employee, set `device_uid` to match the UID on the device

**Tested with:** ZKTeco K40, K80, F18, iClock series (any pyzk-compatible device)

---

## 🔄 Auto-Sync

Fingerprint logs are synced from the device every **5 minutes** automatically.

Manual sync via API:
```bash
# Get token first
TOKEN=$(curl -s -X POST http://localhost:8000/auth/login \
  -d "username=admin&password=admin123" | python -c "import sys,json; print(json.load(sys.stdin)['access_token'])")

# Sync
curl -X POST http://localhost:8000/attendance/sync \
  -H "Authorization: Bearer $TOKEN"
```

---

## 🛠️ Tech Stack

| Layer | Technology |
|---|---|
| API | FastAPI |
| Database | PostgreSQL (local) |
| ORM | SQLAlchemy 2.0 |
| Migrations | Alembic |
| Auth | JWT (python-jose + passlib bcrypt) |
| Admin Panel | SQLAdmin |
| Fingerprint | pyzk (ZKTeco SDK) |
| Auto-sync | APScheduler |
| Server | Uvicorn |
